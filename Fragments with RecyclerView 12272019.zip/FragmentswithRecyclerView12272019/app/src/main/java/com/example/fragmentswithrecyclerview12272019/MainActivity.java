package com.example.fragmentswithrecyclerview12272019;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvName, tvPhone;
    EditText etName, etPhone;
    Button btnAddContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvName = findViewById(R.id.tvName);
        tvPhone = findViewById(R.id.tvNumber);
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etNumber);
        btnAddContact = findViewById(R.id.btnAddContact);

    }
}
